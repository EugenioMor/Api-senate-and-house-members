function house() {
    var miembros = "";
    for (var i = 0; i < data2.results[0].members.length; i++) {
        miembros += "<tr>" + "<td>" + "<a href=" + data2.results[0].members[i].url + ">" + data2.results[0].members[i].first_name  + "</a>" + "<td>" +  data2.results[0].members[i].middle_name + "</td>" + "<td>" + data2.results[0].members[i].last_name + "</td>"  + "<td>" + data2.results[0].members[i].party + "</td>" + "<td>" + data2.results[0].members[i].state + "</td>" + "<td>" + data2.results[0].members[i].seniority + "</td>" + "<td>" + data2.results[0].members[i].votes_with_party_pct + "</td>" + "</tr>"
    }
    return miembros
}

document.getElementById("senate").innerHTML = house()