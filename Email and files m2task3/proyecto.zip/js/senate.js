function senadores() {
    var miembros = "";
    for (var i = 0; i < data.results[0].members.length; i++) {
        miembros += "<tr>" + "<td>" + "<a href=" + data.results[0].members[i].url + ">" + data.results[0].members[i].first_name  + "</a>" + "<td>" +  data.results[0].members[i].middle_name + "</td>" + "<td>" + data.results[0].members[i].last_name + "</td>"  + "<td>" + data.results[0].members[i].party + "</td>" + "<td>" + data.results[0].members[i].state + "</td>" + "<td>" + data.results[0].members[i].seniority + "</td>" + "<td>" + data.results[0].members[i].votes_with_party_pct + "</td>" + "</tr>"
    }
    return miembros
}
document.getElementById("senate").innerHTML = senadores()