var url = "https://api.propublica.org/congress/v1/113congress/senate/members.json"
fetch(url, {
        method: "GET",
        headers: {
            "X-API-Key": "ztTqbGgq9BJZzxW4JjrDpoykcJWkYDDWKbcAPANY",

        }
    })
    .then(function (response) {
        return response.json();
    })
    .then(function (data) {

        app.miembros = data.results[0].members;
        console.log(json);

    })

var app = new Vue({
    el: "#app",
    data: {
        miembros: []
    }
});