var url = "https://api.propublica.org/congress/v1/113congress/house/members.json"
fetch(url, {
        method: "GET",
        headers: {
            "X-API-Key": "ztTqbGgq9BJZzxW4JjrDpoykcJWkYDDWKbcAPANY",

        }
    })
    .then(function (response) {
        return response.json();
    })
    .then(function (data) {

        app.miembros = data.results[0].members;
        separarMiembros();
        calcularMiembros();
        promedioPorcentaje();
        leastEngaged(0.1);
        mostEngaged(0.1);
        leastLoyalty(0.1);
        mostLoyalty(0.1);
    })

var app = new Vue({
    el: "#app",
    data: {
        miembros: [],
        statistics: {
            "numberOfDemocrats": 0,
            "miembrosDemocrats": [],
            "votesWithPartyD": 0,
            "numberOfRepublicans": 0,
            "miembrosRepublicans": [],
            "votesWithPartyR": 0,
            "numberOfIndependents": 0,
            "miembrosIndependents": [],
            "votesWithPartyI": 0,
            "leastEngaged": [],
            "mostEngaged": [],
            "leastLoyal": [],
            "mostLoyal": [],
            "total": 0
        }
    }
})

function separarMiembros() {
    app.statistics.miembrosDemocrats = app.miembros.filter(function (elemento) {
        return (elemento.party === "D");
    });
    app.statistics.miembrosRepublicans = app.miembros.filter(function (elemento) {
        return (elemento.party === "R");
    })
    app.statistics.miembrosIndependents = app.miembros.filter(function (elemento) {
        return (elemento.party === "ID");
    })
}

function calcularMiembros() {
    app.statistics.numberOfDemocrats = app.statistics.miembrosDemocrats.length
    app.statistics.numberOfRepublicans = app.statistics.miembrosRepublicans.length
    app.statistics.numberOfIndependents = app.statistics.miembrosIndependents.length
    app.statistics.total = (app.statistics.miembrosIndependents.length) + (app.statistics.miembrosRepublicans.length) + (app.statistics.miembrosDemocrats.length)
}

function promedio(miembros) {
    let sumaD = 0;
    for (let i = 0; i < miembros.length; i++) {
        sumaD += (miembros[i].votes_with_party_pct || 0);
    }
    return (sumaD / miembros.length)
}

function promedioPorcentaje() {
    app.statistics.votesWithPartyD = promedio(app.statistics.miembrosDemocrats);
    app.statistics.votesWithPartyR = promedio(app.statistics.miembrosRepublicans);
    app.statistics.votesWithPartyI = promedio(app.statistics.miembrosIndependents);
}
// //Mas y menos comprometidos

function leastEngaged(porcentaje) {
    var ordenados2 = app.miembros.sort((mv1, mv2) => {
        return mv1.missed_votes_pct - mv2.missed_votes_pct
    })
    app.statistics.leastEngaged = ordenados2.slice(-ordenados2.length * porcentaje);
    return app.statistics.leastEngaged
}

function mostEngaged(porcentaje) {
    var ordenados2 = app.miembros.sort((mv1, mv2) => {
        return mv1.missed_votes_pct - mv2.missed_votes_pct
    })
    app.statistics.mostEngaged = ordenados2.slice(0, ordenados2.length * porcentaje);
    return app.statistics.mostEngaged
}

// Más y menos leales

function leastLoyalty(porcentaje) {
    var ordenados = app.miembros.sort((mv1, mv2) => {
        return mv1.votes_with_party_pct - mv2.votes_with_party_pct
    })
    app.statistics.leastLoyal = ordenados.slice(0, (ordenados.length * porcentaje));
    return app.statistics.leastLoyal
}

function mostLoyalty(porcentaje) {
    var ordenados = app.miembros.sort((mv1, mv2) => {
        return mv1.votes_with_party_pct - mv2.votes_with_party_pct
    })
    app.statistics.mostLoyal = ordenados.slice(-ordenados.length * porcentaje);
    return app.statistics.mostLoyal
}