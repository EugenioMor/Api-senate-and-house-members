var members = data.results[0].members;
var statistics = {
    "numberOfDemocrats": 0,
    "miembrosDemocrats": [],
    "votesWithPartyD": 0,
    "numberOfRepublicans": 0,
    "miembrosRepublicans": [],
    "votesWithPartyR": 0,
    "numberOfIndependents": 0,
    "miembrosIndependents": [],
    "votesWithPartyI": 0,
    "leastEngaged": [],
    "mostEngaged": [],
    "leastLoyal": [],
    "mostLoyal": [],
    "total": 0
}
separarMiembros();
calcularMiembros();

function separarMiembros() {
    statistics.miembrosDemocrats = members.filter(function (elemento) {
        return (elemento.party === "D");
    });
    statistics.miembrosRepublicans = members.filter(function (elemento) {
        return (elemento.party === "R");
    })
    statistics.miembrosIndependents = members.filter(function (elemento) {
        return (elemento.party === "ID");
    })
}

function calcularMiembros() {
    statistics.numberOfDemocrats = statistics.miembrosDemocrats.length
    statistics.numberOfRepublicans = statistics.miembrosRepublicans.length
    statistics.numberOfIndependents = statistics.miembrosIndependents.length
    statistics.total = (statistics.miembrosIndependents.length) + (statistics.miembrosRepublicans.length) + (statistics.miembrosDemocrats.length)
}

function promedio(miembros) {
    let sumaD = 0;
    for (let i = 0; i < miembros.length; i++) {
        sumaD += (miembros[i].votes_with_party_pct || 0);
    }
    return (sumaD / miembros.length)
}

function promedioPorcentaje() {
    statistics.votesWithPartyD = promedio(statistics.miembrosDemocrats);
    statistics.votesWithPartyR = promedio(statistics.miembrosRepublicans);
    statistics.votesWithPartyI = promedio(statistics.miembrosIndependents);
}
promedioPorcentaje();

// Mas y menos leales
var ordenados = members.sort((mv1, mv2) => {
    return mv1.votes_with_party_pct - mv2.votes_with_party_pct
})

function leastLoyalty(ordenados, porcentaje) {
    statistics.leastLoyal = ordenados.slice(0, (ordenados.length * porcentaje));
    return statistics.leastLoyal
}
leastLoyalty(ordenados, 0.1);

function mostLoyalty(miembrosOrdenados, porcentaje) {
    statistics.mostLoyal = miembrosOrdenados.slice(-miembrosOrdenados.length * porcentaje);
    return statistics.mostLoyal
}
mostLoyalty(ordenados, 0.1);

function table1() {
    var number = "<tr>" + "<td>Democrats</td>" + "<td>" + statistics.numberOfDemocrats + "</td>" + "<td>" + statistics.votesWithPartyD.toFixed(2) + "</td>" + "</tr>" + "<tr>" + "<td>Republicans</td>" + "<td>" + statistics.numberOfRepublicans + "</td>" + "<td>" + statistics.votesWithPartyR.toFixed(2) + "</td>" + "</tr>" + "<tr>" + "<td>Independents</td>" + "<td>" + statistics.numberOfIndependents + "</td>" + "<td>" + 0 + "</td>" + "</tr>" + "<tr>" + "<td>Total</td>" + "<td>" + statistics.total + "</td>" + "<td>" + "</td>" + "</tr>"
    return number
}

function table2() {
    var missed = "";
    for (var i = 0; i <= statistics.leastLoyal.length - 1; i++) {
        missed += '<tr><td> <a href="' + statistics.leastLoyal[i].url + '">' + statistics.leastLoyal[i].first_name + ' ' + statistics.leastLoyal[i].last_name + '</td><td>' + statistics.leastLoyal[i].total_votes + '</td><td>' + statistics.leastLoyal[i].votes_with_party_pct + '</td></tr>'
    }
    return missed;

}

function table3() {
    var missed = "";
    for (var i = 0; i <= statistics.mostLoyal.length - 1; i++) {
        missed += '<tr><td> <a href="' + statistics.mostLoyal[i].url + '">' + statistics.mostLoyal[i].first_name + ' ' + statistics.mostLoyal[i].last_name + '</td><td>' + statistics.mostLoyal[i].total_votes + '</td><td>' + statistics.mostLoyal[i].votes_with_party_pct + '</td></tr>'
    }
    return missed;
}

function tablasLoyalty () {
document.getElementById("table1").innerHTML += table1();
document.getElementById("table2").innerHTML = table2();
document.getElementById("table3").innerHTML = table3();
}

tablasLoyalty()